# Phase 4 — Storyboard

Applique le skill `storyboard-ai-ad` (il demande le script et au moins une pub de référence, analyse la référence avec
`watch`, construit la fiche de cohérence puis écrit chaque plan : réplique exacte, prompt d'image, prompt vidéo,
direction son, durée). Ce qui suit s'ajoute à ses règles et l'emporte en cas de conflit — en particulier : pour une
voix hors champ, on ne cite pas la réplique dans le prompt vidéo, contrairement à ce que demande `storyboard-ai-ad`.
Écrire le storyboard avec un petit script Python qui assemble les descripteurs (une variable par personnage, décor,
objet, style) garantit qu'ils sont répétés mot pour mot ; le faire vérifier que les répliques du storyboard sont
exactement celles du script, dans l'ordre.

## Références à lui donner

- La pub swipe du format (pour la structure et le rythme).
- Une créa déjà montée du même produit, si elle existe (pour garder le même rendu d'une créa à l'autre).
- La fiche produit (emballage, mentions interdites) et le style choisi.

## Fiche de cohérence : ce qui a marché

- **Descripteurs complets, identiques mot pour mot** dans chaque prompt d'image (personnage, tenue, décor,
  emballage, style). Un repère court et identique dans chaque prompt vidéo. Jamais « le même homme ».
- **Personnages** : âge, peau, forme du visage, cheveux, signes distinctifs, carrure, tenue de jour et tenue de nuit
  si l'histoire passe par la nuit. Chaque nouvelle créa a un **nouveau héros** (l'utilisateur l'a demandé : Meta voit
  un visage différent) qui ne doit pas ressembler aux précédents.
- **Emballage** : décrire une version neutre qui ne porte que le nom (et un petit pictogramme), sans aucune mention
  de maladie, même si le vrai emballage en porte. Ne jamais donner la photo du vrai emballage en référence si elle
  porte ces mentions : le modèle les recopie.
- **Objets récurrents** (carnet, théière, capsules) : un descripteur chacun ; compter ce qui doit être compté
  (« a neat row of seven capsules »).
- **Décors** : réalistes pour le pays, **urbains et classe moyenne par défaut** — pour la Gambie/Sénégal par
  exemple : maison en parpaing enduit et peint, ventilateur au plafond, fenêtre à lames de verre avec grille
  anti-effraction et rideau léger, carrelage ; devant : sol cimenté, portail en métal, rue sablonneuse avec maisons
  voisines et poteaux électriques. Pas de banco, de volets rustiques ni de sol en terre sauf demande.
- **Décor d'un personnage « louche »** : un lieu sans fenêtre (on ne voit pas l'heure, donc la lumière reste la même
  sur tous les plans), qui raconte le personnage (pharmacie de luxe trop parfaite pour un faux docteur), réchauffé
  (bois clair, plantes) pour ne pas être froid. Le cadrer devant un fond qui le détache (sa blouse blanche
  disparaissait sur un mur blanc).
- **Lumière qui raconte** : la progression d'une histoire peut passer par la lumière (nuit bleue → crépuscule du
  doute → aube → plein matin).

## Mode de parole : à décider plan par plan

| Situation | Mode | Conséquence en génération |
|---|---|---|
| Narrateur ou héros qui raconte (voix off) | Voix off, personne ne parle à l'image | Vidéo Kling **sans son**, et **ne pas citer la réplique** dans le prompt vidéo (sinon les lèvres bougent quand même) ; décrire l'action, le visage, « mouth closed, silent » |
| Personnage qui parle face caméra | Dialogue, lèvres synchronisées | Soit Kling avec son (il dit la réplique avec une voix inventée, qui varie d'un plan à l'autre), soit une voix ElevenLabs + synchronisation des lèvres ; voir `voix.md` |
| Son réel utile (rire, bruit synchronisé) | Son généré pour ce plan seul | Kling avec son, prompt sans aucune réplique : « Audio: only her laughter, no speech, no music » |

Dans les prompts vidéo, quand deux personnages parlent dans la même pub, ajouter à la fin une courte description de
voix différente pour chacun (âge, timbre, énergie, accent) pour éviter qu'ils se ressemblent.

## Durées

Estimation à 150 mots/min pour le storyboard ; la vraie durée de chaque plan sera recalculée sur la voix enregistrée
(phase 5, `scripts/durees_plans.py`). Kling impose 3 s minimum par clip.

## Plans délicats (prévoir plusieurs essais d'image)

Trois personnages + un échange d'objet ; une main qui tient un emballage (les doigts cachent le nom : poser l'objet
sur la paume ouverte) ; un plan très large où le héros est minuscule ; du texte dans l'image (garder des mots très
courts : « 4 WEEKS », « HEALTH CENTRE »).

## Livrable

`crea-N/storyboard.md` (le format du skill storyboard-ai-ad), plus un résumé pour l'utilisateur : distribution,
décors, découpage, plans délicats, et les prompts des fiches de référence à générer en premier.
