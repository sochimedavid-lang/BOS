# Phase 3 — Script

## La méthode de Mark en 4 temps

1. **Analyser la recherche** (déjà fait en phase 1 : on repart des 4 documents).
2. **Analyser le swipe** : transcription + structure, sans rien écrire.
3. **Réécrire** pour le produit : garder la structure d'argument du swipe, remplacer tout le contenu par celui de la
   recherche (UMP, UMS, grande idée, métaphore, mots des clients).
4. **Relire (« chiefing »)** : clarté (phrases courtes, une idée par phrase — la langue de la pub est souvent la 2e
   ou 3e langue de la cible), voix du client (ses mots, ses images culturelles), ton humain, conformité.

Mark : « Stop writing copy and start crafting arguments. » Chaque phrase mène vers la croyance visée ; on sait qu'on
a fini quand l'argument ne laisse qu'une conclusion possible.

## Gabarit du fichier `script.md`

```
# Créa N — <Nom du format> (vX)
**Format de référence :** <pub swipe> — <structure en une ligne>
**Question à laquelle elle répond :** …   **Croyance visée :** …
**Langue / voix :** …   **Héros :** …   **Durée estimée :** <mots> mots ≈ <s> s
**Ce qui est cité parce que vrai aujourd'hui :** …
**Ce qui n'est pas cité :** prix, offre groupée, ingrédients non confirmés, résultats chiffrés, religion, peur…
_Historique : v1 … ; v2 … (raison)_

## Script
<sections nommées : Accroche, Recadrage, Mécanisme, Solution, Produit, Confiance + garantie, Sécurité, Appel à l'action>

## Ce qui la sépare des autres créas (dès la 2e)   ← tableau question / croyance / forme / émotion / héros / décor
## Relecture (chiefing)                           ← clarté, voix du client, ton, règles
## Points à valider                               ← les vraies décisions pour l'utilisateur
## Accroches alternatives à tester                ← 2 ou 3
## Croyances couvertes                            ← tableau croyance → où dans le script (et celles non couvertes)
```

## Durée

150 mots ≈ 60 s de voix ; une pub de 60 à 80 s convient. Au-delà, proposer de resserrer. La durée réelle sera
mesurée sur la voix enregistrée (phase 5).

## Règles d'écriture apprises

- **Toujours** une ligne de sécurité (« If there's pain, or blood… see a doctor first ») pour un produit de santé,
  formulée en conseil général, jamais « your … ».
- **Appel à l'action complet** : l'utilisateur veut l'action + les deux réassurances (« Click below to order. Free
  delivery today, and cash on delivery — you pay only when it's in your hand. »). « Free delivery today » est son
  choix : le garder. En français : « Cliquez en bas pour commander. Livraison gratuite aujourd'hui, et vous payez
  seulement quand le produit est dans votre main. » ; sécurité : « Une douleur forte, du sang, un gonflement : ça,
  c'est le médecin d'abord. » (à adapter au produit, registre choisi dans la fiche produit).
- **Garantie** : la durée citée doit être celle de la page et des conditions ; la signaler si elle n'est pas encore
  en place.
- **Pas de prix** ni d'offre groupée dans la vidéo sauf décision explicite (le prix peut changer).
- **Nombres** : la durée du plan et la posologie sont des faits fixes, identiques dans toutes les créas et sur la
  page. Si on les change, toutes les créas déjà faites sont à corriger (prévoir le coût).
- **Personnages qui parlent** : une réplique par plan, courte ; le produit qui répond reste calme, ne se moque pas.
- **Méchant comique** : caricature d'un comportement (vendeur de miracles), jamais d'un groupe ; jamais menaçant.
- **Différencier les créas** : mesurer le recouvrement avec les précédentes :
  `python scripts/recouvrement_scripts.py crea-1/script.md crea-2/script.md` → au-delà de ~25 % (hors faits fixes
  et appel à l'action), changer d'argument, pas seulement de mise en scène.
- **Demandes de l'utilisateur pendant l'écriture** : s'il veut « plus de texte », ajouter des moments humains
  (proches qui réagissent, doute, pression sociale) plutôt que des promesses ; s'il veut annoncer un résultat, proposer
  une version vraie (progrès partiel, attribué aux habitudes, au conditionnel) et expliquer pourquoi.

## Porte de validation

Montrer le script complet (en citation), ce qui change par rapport aux autres créas, les points à trancher, la durée.
Ne passer au storyboard qu'après un « je valide ».
