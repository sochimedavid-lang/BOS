# Organisation des dossiers d'un produit

Un dossier par produit, un sous-dossier par créa. Les fichiers lourds de génération peuvent rester dans
`Downloads` (c'est là que l'utilisateur les dépose depuis le site Higgsfield) ; le dossier produit garde alors
leurs chemins dans `SUIVI.md`.

```
Desktop\Claude\Pubs IA\<Produit>\
├── SUIVI.md                    ← état du projet : étape en cours, décisions, chemins, crédits dépensés
├── fiche-produit.md            ← copie remplie de assets/fiche-produit.md
├── 01-recherche\               ← les 4 documents fondateurs (ceux de l'utilisateur priment) + PDF de la page
├── 02-swipes\                  ← rapports watch des pubs de référence + choix des formats
├── crea-1-<nom-du-format>\
│   ├── script.md
│   ├── storyboard.md
│   ├── voix-off.txt            ← texte exact à envoyer à ElevenLabs
│   ├── images\
│   │   ├── references\         ← fiches retenues (ref_<personnage>.png, ref_<decor>.png, ref_accessoires.png)
│   │   └── plans\              ← image retenue par plan : clip01.png … clipNN.png
│   ├── videos\                 ← clip01.mp4 … (originaux remplacés gardés en clipNN_<raison>.mp4)
│   ├── voix\                   ← prise ElevenLabs + whisper-words.json
│   └── montage\                ← projet montage-pub-ia (edit.json, RUN.md, renders\)
└── crea-2-<nom>\ …
```

Les candidates (3 variantes par image) et les fichiers de travail vont dans le dossier de travail temporaire de la
session (scratchpad) ; seules les images retenues sont copiées dans `images\`. L'utilisateur a demandé « un dossier
dans lequel tu mets les images que tu as sélectionnées » : c'est `images\plans\`, avec des noms par numéro de plan.

## SUIVI.md — ce qu'il doit contenir

- Produit, marché, langue, offre, ce qui est vrai aujourd'hui (posologie, garantie, livraison, paiement).
- Décisions de l'utilisateur, datées (ex. « garantie portée à 60 jours », « plan de 4 semaines », « style : 3D »).
- Pour chaque créa : format, style, héros, étape atteinte, fichiers, crédits dépensés, défauts connus.
- Ce qui reste à faire (page produit à corriger, créas suivantes, lancement).

## Nommer et renommer

- Relister le dossier juste avant tout renommage : un fichier ajouté ou supprimé entre-temps décale tout
  (erreur déjà commise : 5 clips décalés).
- Nommer par numéro de plan (`clip07.png`, `clip07.mp4`), jamais par l'identifiant de génération seul ; garder
  l'identifiant d'origine dans `SUIVI.md` si besoin.
- Avant de remplacer un fichier validé, le garder sous un nom explicite (`clip12_8weeks.mp4`, `voiceover_v1.mp3`).
