# Phases 6 et 7 — Montage et corrections

Applique le skill `montage-pub-ia` (projet par pub : `clips/`, `audio/`, `edit.json`, `RUN.md`). Ce qui suit
complète ses instructions.

## Deux cas de départ

- **Voix off** : la piste voix est la prise ElevenLabs. Les coupes tombent ~0,1 s avant chaque phrase (temps des mots
  de la transcription, recalés sur les silences).
- **Dialogue joué par les clips** (Kling avec son) : il n'y a pas de voix off ; on fabrique la piste « voix » en
  découpant dans chaque clip sa réplique (fenêtre début → fin mesurée sur la transcription et le volume), au même
  niveau pour toutes, mises bout à bout. L'image de chaque clip est coupée avec le même décalage que son son : les
  lèvres restent synchronisées. On peut avancer une coupe image (montage en L) pour éviter une fin ratée.

## Musique et bruitages

- **Licence** : Pixabay (usage commercial, sans attribution ; éviter « Content ID registered ») ou la musique déjà
  utilisée par l'utilisateur. Pas la bibliothèque CapCut (réservée à TikTok/CapCut, pas aux pubs Meta).
- **Téléchargement** : l'API Pixabay de l'utilisateur ne donne pas l'audio (erreur 403) → lui donner les liens exacts,
  il télécharge, il dépose dans un dossier `son\`. Demander seulement ce qui manque, réutiliser les bruitages déjà
  téléchargés pour les créas précédentes.
- **Choix** : la musique n'a pas à être locale ; elle doit coller au ton (comique, posé, chaleureux). Mesurer avant de
  choisir (`analyze-audio.py music`) et expliquer le choix avec les chiffres.
- **Bruitages** : peu, chacun dans une pause, pic calé sur la coupe ou le mot ; pas de « boom » ni d'impact
  cinématographique dans une pub calme. Proposer la liste avec les moments avant de télécharger.

## Sous-titres

Karaoké style « Miracle Balm » par défaut (minuscules Montserrat ExtraBold, blanc, mot prononcé en vert #A3FB02).
Blocs découpés à la main dans `script.txt` ; chiffres en chiffres (« 4 weeks », « 14 days ») ; le texte vient du
script, la transcription ne donne que les temps. Pour un journal ou des chapitres, on peut ajouter un titre en haut
(« WEEK 1 / 4 ») dans le même fichier de sous-titres.

## Rendre vite

- Préparer sous-titres, musique et bruitages **avant** le premier rendu, puis
  `stage-ad.py edit.json --render renders/<nom>-v1.mp4 --ass captions/captions.ass` : un seul encodage (Intel Quick
  Sync quand le PC l'a).
- Correction de son seul : `--swap-audio renders/v1.mp4 --final renders/v2.mp4` (≈ 1 min, image intacte).
- Lancer les rendus en arrière-plan avec un délai long (≥ 1 h).
- Le PC de l'utilisateur est lent (2 cœurs) et souvent occupé : ne pas promettre une durée précise.

## Retouches d'image courantes

- Couper les silences de début de clip (Kling commence souvent par 1 s de silence).
- Couper avant une fin ratée (lueur qui délave l'objet, objet parasite qui apparaît).
- Assombrir et bleuir une scène de nuit trop claire (pré-étalonner le clip avec ffmpeg `eq` + `colorbalance`, garder
  l'original `_orig`).
- Remplacer un mot mal prononcé (voir `voix.md`).

## Livrer

Après validation du montage : habillage (accroche en haut + carte de fin) avec le skill `habillage-pub`.


Envoyer la vidéo (SendUserFile), avec : ce que contient le montage, la liste des bruitages et leurs moments, et
**les moments précis à écouter ou regarder**. Versionner (`-v1`, `-v2`, `-4weeks`…) et garder les anciennes versions.

## Corrections : choisir la plus petite intervention

| Demande | Intervention |
|---|---|
| Volume d'un bruitage, de la musique | Modifier `edit.json` → `--swap-audio` |
| Un mot de voix off | Greffer le mot pris ailleurs dans la même voix, ou régénérer la phrase → `--render` |
| Une réplique d'un clip Kling (dialogue) | Chercher le mot ailleurs dans la même voix ; sinon régénérer ce seul plan (avec accord), remplacer, décaler bruitages et musique qui suivent, `--render` |
| Un fait qui change dans toutes les créas (ex. durée du plan) | Lister chaque occurrence (voix, sous-titres, plans), chiffrer chaque correction, faire valider, corriger créa par créa |
| Un sous-titre | Modifier `script.txt` ou un temps dans `whisper-words.json` → refaire les sous-titres → `--render` |
