# Conformité (Meta + vente à la livraison en Afrique)

À relire à chaque script et avant chaque génération. Ces règles viennent des règles publicitaires Meta, des lois locales
de protection du consommateur (publicité trompeuse) et des décisions de l'utilisateur.

## Ce qu'une pub ne fait jamais

- **Faire peur** (dialyse, opération, sonde, mort, « avant qu'il ne soit trop tard »).
- **Parler de la santé du spectateur à la 2e personne** (« your joints », « if your blood sugar is high »). Parler d'un
  personnage, des « men over fifty », ou donner un conseil général.
- **Viser la religion** (attribut personnel pour Meta) : pas d'heure de prière, pas de référence religieuse, même si la
  recherche en parle (une technique proche d'une pratique religieuse ne se cite qu'après validation d'un religieux,
  et plutôt sur la page). Cela vaut aussi pour le son : pas d'appel à la prière, de cloches ni de chant religieux
  dans les ambiances (une ambiance de rue africaine générée ou téléchargée en contient souvent).
- **Allégation de maladie** : le produit ne « guérit », « soigne », « fait baisser la tension » pas. Il « accompagne »,
  « soutient », avec des habitudes. Le mot « cure » n'est jamais prononcé, même par un méchant.
- **Résultat chiffré ou daté promis** (« 1 fois au lieu de 3 », « en 7 jours »). Un progrès se dit partiel, au
  conditionnel, et attribué à ce qui le cause vraiment (habitudes).
- **Faux médecin, faux client, faux expert** : pas de blouse crédible, pas de « Dr », pas de témoignage réaliste
  présenté comme vrai. Un personnage 3D clairement fictif ou une caricature (le faux docteur comique) est acceptable.
- **Fausse urgence ou rareté** (« they sell out », compte à rebours). « Free delivery today » est le choix de
  l'utilisateur : gardé.
- **Prix** dans la vidéo, sauf décision explicite.
- **Mentions de maladie à l'écran** (emballage) : version de l'emballage qui ne porte que le nom.
- **Concurrent nommé**, marque tierce (paiement mobile, etc.).

## Ce qu'une pub santé fait toujours

- Une ligne « voyez un médecin d'abord » (douleur, sang, symptôme inhabituel), sans musique comique dessous.
- Des faits vérifiables seulement (posologie réelle, durée de la boîte, garantie réelle, paiement à la livraison).
- La même durée de plan, la même garantie et la même posologie que la page.

## Cas particuliers

- **Humain IA réaliste** : voir `styles.md` (risque de faux témoignage, mention IA possible).
- **Méchant comique** : caricature d'un comportement, jamais d'une ethnie, d'une religion ou d'un groupe.
- **Image qui évoque l'alcool** (bouteilles longues brunes ou vertes) dans un pays majoritairement musulman : la
  remplacer par des pots ou flacons compte-gouttes.
