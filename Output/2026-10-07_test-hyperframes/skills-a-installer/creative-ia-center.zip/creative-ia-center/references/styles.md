# Styles de créa

Le style est choisi par l'utilisateur, créa par créa. Il ne change pas la méthode (recherche → swipe → script →
storyboard → génération → montage) mais il change quatre choses : les pubs de référence à chercher, le descripteur de
style répété dans tous les prompts, la manière de faire parler les personnages, et les risques.

Pose la question avec les options ci-dessous (et « autre ») ; si l'utilisateur hésite, rappelle l'idée de Mark : ce
qui arrête le défilement, c'est le **contraste** avec les pubs ordinaires, pas le réalisme.

## 3D façon Pixar (testé, 3 créas validées)

- **Pour quoi** : expliquer un mécanisme du corps sans gêne (coupes anatomiques propres), raconter une petite
  histoire, faire parler une mascotte. Rend parlable un sujet tabou ; ne ressemble ni aux faux médecins ni aux
  photos produit.
- **Descripteur de style** (à répéter mot pour mot, en finissant chaque prompt d'image) :
  `Polished 3D animated-film style with soft rounded proportions, expressive faces, gently simplified detail,
  warm cinematic lighting, rich earth-tone colors, soft shallow depth of field, vertical 9:16 composition.`
  - Variante pour un décor blanc ou clinique (sinon tout vire à l'orange) : remplacer la partie lumière par
    `soft warm cinematic lighting, creamy whites with warm gold and honey-wood accents`.
- **Cohérence** : fiche personnage 16:9 (face, profil, plein pied, 2 tenues si jour/nuit), donnée en référence à
  chaque image de plan.
- **Parole** : voix off (un narrateur, ou le héros qui raconte) **ou** dialogue face caméra (mascotte, méchant).
  Voir `voix.md` pour choisir.
- **Risque** : faible ; garder les personnages clairement fictifs.

## Humain IA réaliste (façon UGC)

- **Pour quoi** : faux selfie, témoignage mis en scène, démonstration à la maison. Fort taux d'arrêt, mais c'est
  aussi le format le plus surveillé.
- **Descripteur de style** (exemple, à adapter) : `Photorealistic vertical smartphone video frame, natural window
  light, slightly handheld framing, real skin texture and natural imperfections, everyday home setting, no studio
  look, 9:16.`
- **Cohérence** : le visage dérive vite d'un plan à l'autre (défaut vu dans une pub de référence). Utiliser une fiche
  personnage forte et, si possible, un personnage entraîné (skill `higgsfield-soul-id`). Vérifier le visage à
  chaque plan.
- **Parole** : le personnage parle face caméra → il faut une vraie synchronisation des lèvres sur une seule voix
  (piste ElevenLabs donnée en référence audio à un modèle qui l'accepte, ex. Seedance 2.5 `--audio-references` ;
  tester sur un plan et vérifier le coût avant le lot).
- **Risques (à dire à l'utilisateur avant de commencer)** :
  - Un humain IA présenté comme un vrai client ou un vrai médecin = faux témoignage : trompeur en droit de la
    consommation et contraire aux règles Meta. Pas de blouse, pas de « Dr », pas de résultats chiffrés « vécus ».
  - Préférer une mise en scène assumée (personnage qui explique, démonstration) à un témoignage.
  - Meta peut ajouter une mention « contenu IA » ; ne pas chercher à la contourner.

## 2D cartoon / motion design

- **Pour quoi** : explications rapides, listes de bénéfices, infographies animées ; peu coûteux à rendre cohérent.
- **Descripteur** (exemple) : `Clean flat 2D cartoon illustration, bold outlines, simple shapes, limited warm color
  palette, vertical 9:16 composition.`
- **Parole** : voix off de préférence (les bouches 2D synchronisées sont moins convaincantes).

## Mascotte produit

- **Pour quoi** : faire parler le produit lui-même (duel avec un méchant, réponses aux objections).
- **Cohérence** : fiche de la mascotte avec l'emballage réel en référence ; nom lisible, visage placé là où
  l'utilisateur le veut (dans la série testée : visage en haut, nom en bas, bras et jambes « rubber hose » à gants
  blancs). Quand la scène montre ce que le client reçoit (paiement, sachet en main), montrer l'**emballage réel
  sans visage** : le client ne reçoit pas une mascotte.
- **Parole** : dialogue face caméra, voix distincte de celle du méchant.

## Pâte à modeler, anime, autres

Possibles avec le même déroulé. Écrire un descripteur de style précis, chercher des pubs de référence dans ce style,
et tester 1 image + 1 vidéo avant de lancer un lot.

## Ce que le style change dans les autres phases

| Phase | Ce qui change |
|---|---|
| Swipe | Chercher des pubs qui marchent **dans ce style** (le rythme et la mise en scène en dépendent) |
| Storyboard | Descripteur de style ; mode de parole par plan ; cadrages (le réaliste supporte moins les plans très larges) |
| Génération | Modèle d'image (Nano Banana Pro par défaut ; Soul pour un humain réaliste cohérent) ; modèle vidéo |
| Voix | Voix off simple ou synchronisation des lèvres |
| Conformité | Risque « faux témoignage » maximal en réaliste |
