# Phase 1 — Recherche : les 4 documents fondateurs

## Pourquoi on commence là

Mark : « la plupart des rédacteurs croient connaître le marché et sautent la recherche ; ils devinent ce que le
marché veut entendre ». La recherche donne les mots exacts des clients, leurs douleurs, ce qu'ils ont déjà essayé,
ce qu'ils croient, et le niveau de méfiance du marché. Tout le script en découle.

## Les 4 documents (SOP « Foundational Docs » de Mark)

| Document | Ce qu'il contient | Comment on l'obtient |
|---|---|---|
| Recherche | Démographie, douleurs, solutions essayées, concurrents, objections, verbatims, sophistication du marché | Recherche approfondie, ≥ 6 pages |
| Avatar | Profil, douleurs, objectifs, moteurs émotionnels, citations classées, parcours émotionnel | Modèle `assets/mark-builds-brands/modele-avatar.txt` |
| Offer brief | Conscience, sophistication, grande idée, métaphore, UMP, UMS, guru, histoire de découverte, objections, chaînes de croyances, tunnel | Modèle `assets/mark-builds-brands/modele-offer-brief.txt` |
| Croyances nécessaires | 6 croyances maximum, en « I believe that… » | Prompt de Mark après le transcript sur « l'argument, pas les mots » |

Les prompts exacts de Mark sont dans `assets/mark-builds-brands/sop-documents-fondateurs-original.txt` ; les deux
documents de méthode à téléverser au prompt n° 2 sont `methode-recherche-partie-1.txt` et `-partie-2.txt`.

## Déroulé

1. **Préparer le prompt n° 1 pour l'utilisateur** : remplir `[EXPLAIN WHAT YOU'RE SELLING AND TO WHO]` à partir de
   la fiche produit (produit, pays, cible, offre réelle, mode d'emploi réel, ce qu'on ne doit pas promettre), et
   produire le **PDF de la page produit** (captures de la page en une seule PDF : le skill `pdf` ou les captures que
   l'utilisateur envoie). Préparer aussi le prompt n° 3 : remplacer « Open AI's new tool called deep research » par
   l'outil choisi, et y ajouter le pays, la langue, les sources locales à fouiller (groupes Facebook, commentaires
   YouTube/TikTok, avis Jumia…), les solutions locales déjà essayées, et la consigne de signaler toute citation venue
   d'un autre pays. Livrer le tout dans `01-recherche/prompts-recherche.md`, prêt à coller dans l'ordre.
2. **Outil de recherche** : recommander Claude (Research). Constat sur la série testée : Claude le plus fiable ;
   Gemini utile pour des idées culturelles mais a inventé un fait et mal lu l'offre ; GPT trop générique. L'utilisateur
   peut lancer les trois et me donner les résultats à comparer.
3. **Enchaîner les prompts dans la même conversation** de l'outil (il garde le contexte) : recherche (prompts 1 à 3),
   puis avatar, puis offer brief, puis croyances (transcript + prompt 2).
4. **Lire les 4 documents en entier** quand l'utilisateur les envoie, puis lui restituer :
   - le marché (qui, douleur, psychologie, sophistication) ;
   - l'offre (grande idée, UMP, UMS, métaphore, guru) ;
   - les limites que le script devra respecter ;
   - ce que ça implique pour une pub (ce qui est transposable de la structure de Mark, ce qui ne l'est pas) ;
   - ce qui manque ou n'existe pas encore (preuves, verbatims locaux, composition, contact nommé).
5. **Ses documents priment** sur tout brouillon que j'aurais fait ; je le dis et je travaille à partir des siens.

## Points de vigilance tirés de l'expérience

- **Vérifier le mode d'emploi réel** avant toute recherche : une page peut afficher une posologie fausse, et la
  plainte principale des clients en découler (« seulement 7 capsules » alors qu'un sachet dure 14 jours).
- **Les délais d'effet** : ne jamais reprendre un délai annoncé par des fiches de vendeurs (ex. « effets en
  14 jours ») comme promesse. Fixer une durée de plan défendable avec l'utilisateur (cohérente avec la FAQ de la
  page et la garantie), présenter les étapes intermédiaires comme des étapes, et attribuer les premiers mieux aux
  habitudes plutôt qu'au produit quand c'est ce qui est vrai.
- **Les citations** : la recherche trouve souvent des verbatims d'autres pays. Les signaler comme tels ; demander à
  l'utilisateur des avis de vrais clients locaux (équipe de confirmation des commandes).
- **Ce que la recherche propose mais qui n'existe pas** (conseiller nommé, numéro, plan structuré, garantie plus
  longue) : ne le citer en pub qu'une fois mis en place.
