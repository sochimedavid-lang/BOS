# Voix

## Choisir l'approche

| Approche | Quand | Avantages | Limites |
|---|---|---|---|
| **Voix off ElevenLabs, une seule prise** | Narrateur ou héros qui raconte (journal, explication) | Une seule voix stable du début à la fin, texte exact, rythme posé | Personne ne parle à l'image ; il faut empêcher Kling de bouger les lèvres (pas de réplique dans le prompt vidéo) |
| **Dialogue joué par Kling (son activé)** | Personnages face caméra (méchant, mascotte) | Lèvres synchronisées d'office, jeu d'acteur vivant (rires, indignation) | Voix inventée qui peut varier d'un plan à l'autre ; mots parfois écorchés ; coût 2 cr/s |
| **Voix ElevenLabs + synchronisation des lèvres** | Humain réaliste qui parle, ou dialogue où la voix doit être parfaite | Même voix partout, lèvres synchronisées | À tester sur un plan avant le lot (modèle acceptant une référence audio, ex. Seedance 2.5) ; coût à vérifier |

Si deux personnages parlent, leurs voix doivent être nettement différentes (âge, timbre, énergie) : l'utilisateur
trouverait bizarre qu'ils se ressemblent.

## ElevenLabs

- **L'utilisateur choisit la voix** (identifiant de voix ElevenLabs). Il peut générer lui-même dans ElevenLabs
  (le texte prêt à coller est dans `crea-N/voix-off.txt`) ou me laisser faire avec sa clé API.
- **Clé API** : dans `~/.config/elevenlabs/.env` (`ELEVENLABS_API_KEY=…`), jamais dans le chat. Si l'utilisateur la
  colle dans le chat, l'enregistrer dans ce fichier et lui conseiller de la régénérer plus tard.
- **Générer** : `python scripts/elevenlabs_voix.py crea-N/voix-off.txt --voice <id> --out crea-N/voix/voix-off.mp3`
  (modèle `eleven_v4` par défaut, stabilité 0,5, similarité 0,75 ; `--speed`, `--stability`, `--similarity`
  ajustables). Le format est limité à `mp3_44100_128` sur les offres d'entrée de gamme. Une clé à droits restreints
  peut générer de la voix sans pouvoir lister les voix : c'est normal.
- **Réglages d'une voix déjà utilisée** : le nom du fichier exporté par ElevenLabs les contient
  (ex. `…_sp105_s30_sb50_v4` = vitesse 1,05, stabilité 30, similarité 50, modèle v4). Les réutiliser pour une
  phrase de remplacement.
- **Texte** : un paragraphe par idée (ElevenLabs y marque une pause), tirets et points de suspension pour les
  respirations. Les chiffres écrits en lettres se prononcent mieux (« fourteen days »).

## Contrôle de la voix

1. Transcrire avec les temps de chaque mot :
   `python ~/.claude/skills/montage-pub-ia/scripts/transcribe-words.py voix-off.mp3 -o whisper-words.json`
2. Comparer au texte : la transcription se trompe souvent sur les noms et mots africains (« Lamin » → « Eamon »,
   « attaya » → « attire »). Lister ces mots et demander à l'utilisateur d'écouter : c'est lui qui tranche.
3. Mesurer la durée et les pauses (`analyze-audio.py pauses`), puis calculer la durée des plans
   (`scripts/durees_plans.py`).

## Corriger un mot sans tout refaire

Si la même voix prononce le mot ailleurs (ex. « four » dans « fourteen », « capsules » dans un autre plan) :
découper ce mot (en s'aidant de l'enveloppe de volume pour trouver les silences), égaliser son niveau, l'insérer à
la place de l'ancien avec de courts fondus, et compenser la différence de durée dans le silence suivant pour ne rien
décaler. Vérifier par transcription. Sinon, régénérer la phrase avec les mêmes réglages et la même voix.
