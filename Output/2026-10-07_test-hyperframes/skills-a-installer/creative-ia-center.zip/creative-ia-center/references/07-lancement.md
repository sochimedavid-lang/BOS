# Phase 8 — Avant et après le lancement

## Avant de lancer : la page doit dire la même chose que les pubs

Liste à vérifier avec l'utilisateur (c'est lui qui modifie sa boutique, ou moi s'il me le demande avec un outil
connecté) :
- mode d'emploi / posologie ;
- durée du plan conseillé ;
- garantie (durée, conditions écrites) ;
- livraison et paiement ;
- images qui pourraient tromper (ex. un bol plein de capsules alors qu'un sachet en contient 7) ;
- FAQ cohérente avec tout ce qui précède.

Une pub qui dit « they explain the dose » renvoyant vers une page qui affiche une autre dose est démentie au premier
clic.

## Les textes de la pub

Pour chaque créa : 2-3 textes principaux courts, 2-3 titres, dans la langue de la pub, avec les mêmes règles que le
script (pas de santé du lecteur à la 2e personne, pas de peur, pas de promesse de résultat, pas de prix si la vidéo
n'en donne pas). Reprendre la grande idée et l'accroche de la créa.

## Lancer

Le connecteur Meta Ads doit être autorisé par l'utilisateur (réglages des connecteurs claude.ai ou `/mcp`) avant que
je puisse consulter ou préparer des campagnes. Sans lui, je prépare les textes et la structure, il les saisit.

## Après : lire les chiffres

Les 3 raisons d'échec selon Mark :
1. **Le tunnel** : la pub attire, la page ne convertit pas (panier moyen bas, page incohérente avec la pub).
2. **La force de la créa** : accroche faible, ou absence de mécanisme unique / grande idée ; ou « tomber amoureux du
   swipe ».
3. **Ne pas savoir lire les données** : « on ne perd pas d'argent en pub, on achète des données ».

Par créa, regarder dans l'ordre : taux d'arrêt (accroche), rétention (milieu), clics (appel à l'action), puis
conversions (page). Proposer des variantes d'accroche (déjà listées dans chaque script) plutôt que de tout refaire.
