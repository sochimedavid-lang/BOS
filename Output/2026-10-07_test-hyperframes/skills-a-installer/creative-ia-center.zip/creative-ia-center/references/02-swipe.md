# Phase 2 — Swipe : trouver et analyser les pubs de référence

## Trouver les bonnes pubs

- **Dans le style choisi** (voir `styles.md`) : une pub 3D se modèle sur des pubs 3D, une pub réaliste sur des pubs
  réalistes.
- **Qui marchent** : Mark prend des pubs avec au moins 150 à 200 annonces actives dans la bibliothèque publicitaire
  Meta (signe qu'elles rapportent). Sources : bibliothèque publicitaire Meta, GetHookd (swipe file, onglet
  transcription), recherches de l'utilisateur.
- **Pas forcément dans la même niche** : on copie une structure d'argument, pas un produit.
- Mark met en garde contre « tomber amoureux du swipe » : beaucoup d'annonceurs ne savent pas ce qui convertit.
  Un swipe donne une structure ; la force vient de la recherche (UMP, UMS, grande idée).

## Analyser chaque pub (skill `watch`)

Lance `watch` sur chaque vidéo (URL ou fichier) avec une intention orientée pub : accroche, rythme (coupes par
minute, durée médiane des plans), structure narrative, rôle du produit (moment d'apparition), procédés visuels,
sous-titres, appel à l'action, voix (narrateur, dialogue), musique. Pour chaque pub, restitue :

| Pub | Durée · rythme | Format | Ce qui la fait marcher |
|---|---|---|---|

puis **ce qu'il ne faut pas reprendre** (le plus utile) : peur médicale, interpellation du spectateur sur sa
maladie (« If your … dropped »), ton complotiste (« what nobody told you »), fausse rareté (« they sell out »),
résultats datés et chiffrés, faux client hyperréaliste, durée excessive (une pub de 7 min = ~110 plans à générer).

## Formats déjà identifiés (bibliothèque qui grandit)

| Format | Structure | Croyance qu'il sert le mieux |
|---|---|---|
| Mécanisme express | Cause recadrée (« ce n'est pas X, c'est Y ») → mécanisme en quelques phrases → solution → garantie → appel | Le problème est fréquent et s'explique |
| Ennemi qui explique l'échec | Un « méchant » (molécule, mauvaise habitude, vendeur de miracles) explique pourquoi tout a échoué → le produit le contre | Pourquoi ça va marcher cette fois |
| Duel méchant / produit | Le méchant se vante, le produit lui répond point par point ; la preuve centrale le ruine | Confiance, risque nul (paiement à la livraison, garantie) |
| Journal / témoignage daté | Semaine 1 / 2 / 3 / 4 (ou jour 1 / 7 / 30) sur le ressenti et les habitudes, jamais sur des chiffres | Un plan simple aide, avec patience |
| Messager de confiance | Un proche crédible (ami, fils, coiffeur, aîné) raconte et rassure ; histoire avant produit | Des vraies personnes disent la vérité |

Proposer un format par pub analysée, en une ligne chacun, puis laisser l'utilisateur choisir les créas à faire et
leur ordre. Chaque créa doit viser une **question différente** du client.

## Livrable

`02-swipes/` : un rapport par pub (le `report.md` de watch, complété) et une note de synthèse « formats retenus »
avec, pour chaque créa prévue : format, question à laquelle elle répond, croyance visée, pub de référence.
