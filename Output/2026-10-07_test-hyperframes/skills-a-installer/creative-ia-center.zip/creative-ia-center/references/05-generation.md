# Phase 5 — Génération (Higgsfield)

## Qui génère

Demander à chaque créa (avec le coût des deux options) :
- **L'utilisateur sur le site Higgsfield**, en mode « Unlimited » : les images Nano Banana Pro y sont gratuites. Je
  fournis les prompts (texte complet à coller) et la liste des références à joindre ; il m'envoie les images (zip) ;
  je choisis.
- **Moi en ligne de commande** (`higgsfield`, déjà connecté) : plus rapide, mais tout est payé en crédits
  (pas de mode illimité en CLI).

Les vidéos Kling sont payantes dans les deux cas.

## Coûts constatés (vérifier avec `higgsfield generate cost …` avant un lot)

| Génération | Coût |
|---|---|
| Nano Banana Pro, 1 image 2k | 2 crédits |
| Kling v3.0 `std`, sans son | 1,5 crédit / seconde (minimum 3 s) |
| Kling v3.0 `std`, avec son | 2 crédits / seconde |
| `pro` | plus cher — l'utilisateur l'a refusé ; rester en `std` |

Ordre de grandeur d'une créa de ~25 plans quand je génère tout : ~25 crédits de références, ~150 d'images,
~150 de vidéos. Annoncer le total avant de commencer et le solde restant (`higgsfield account status`).

## 5a. Références (16:9)

Une fiche par personnage récurrent (face, profil, plein pied, expressions utiles, tenues), un décor vide par lieu
récurrent, une planche d'accessoires (emballage, objets). Toujours en **16:9** : le modèle y dessine la pièce ou le
personnage en entier. En 9:16, un décor sort avec des bandes floues en haut et en bas.

3 variantes chacune (`scripts/higgsfield_images.py`), puis planche de comparaison (`scripts/planche_contact.py`),
choix motivé, validation de l'utilisateur. Les fiches retenues vont dans `images/references/`, sans légende ni texte
(recadrer si besoin : les légendes et les vues ratées, comme un visage dessiné sur la tranche d'un sachet, se
recopient dans les plans).

## 5b. Images de plans (9:16)

Chaque prompt commence par « Keep the characters, the setting and the props consistent with the reference images. »
puis le prompt du storyboard ; joindre les références pertinentes pour ce plan (personnage + décor + accessoires).
3 variantes par plan, planches (3 variantes côte à côte), puis **zoomer** avant de choisir :

- compter ce qui doit l'être (le bon nombre de capsules, de personnages) ;
- lisibilité du nom du produit, aucune main devant ;
- mains et doigts, visages (fidèles à la fiche), tenue du bon moment (jour/nuit) ;
- texte parasite (enseignes, affiches illisibles), billets (éviter les dollars s'ils se voient) ;
- un objet qui ressemble à de l'alcool (longues bouteilles brunes/vertes) dans un pays majoritairement musulman ;
- cohérence de décor avec les plans voisins (un décor qui change 2 s et revient fait faux raccord) ;
- composition : le personnage assez grand pour un téléphone, le haut du corps visible quand il tend un objet
  (sinon « tête posée sur l'objet »).

Livrer : la planche de la sélection + les planches de comparaison + un tableau « plan → version → pourquoi », et les
points faibles connus. Copier les retenues dans `images/plans/clipNN.png`. Si l'utilisateur a généré lui-même, faire
le zip de sa sélection renommée par plan s'il le demande.

## 5c. Voix

Voir `voix.md`. Quand le script est en voix off, enregistrer la voix **avant** les vidéos : sa transcription donne la
durée réelle de chaque plan.

## 5d. Vidéos Kling

- **Modèle** : `kling3_0` (Kling v3.0). La CLI n'a pas « Kling 3.0 Omni » image→vidéo (seulement Omni Edit, qui
  demande une vidéo source) ; si l'utilisateur veut Omni, c'est sur le site.
- **Durées** : `python scripts/durees_plans.py` (voix off) → durée de chaque plan arrondie à la seconde supérieure,
  minimum 3 s, **sans marge** : Kling étire la réplique (silences, pauses) sur toute la durée donnée ; une marge ne
  coûte que des secondes en plus. Présenter le tableau des durées et le coût total, attendre l'accord.
- **Son** : sans son pour une voix off ; avec son pour un dialogue joué par Kling ; avec son ponctuellement pour un
  bruit synchronisé (rire). Voir le tableau du mode de parole dans `04-storyboard.md`.
- **Lancer** : `python scripts/higgsfield_videos.py jobs.json --out <dossier>` affiche le coût ; ajouter `--go`
  pour envoyer. Le script lance par vagues de 4, télécharge chaque clip sous `clipNN.mp4`, garde un état et ne
  relance jamais un clip déjà parti ou en échec.
- **Une seule génération par plan.** Un plan raté : le signaler avec le coût d'une reprise, ne rien relancer sans
  accord. Souvent une retouche au montage suffit (couper une fin, un silence de début).

## Contrôle des vidéos

Pour chaque clip : 4 images clés (`scripts/planche_contact.py videos …`), transcription si le clip a du son, et un
regard sur les bouches (planche des visages image par image). Signaler :
- lèvres qui bougent alors que la voix est hors champ ;
- mots mal prononcés (la transcription se trompe souvent sur les noms africains : demander à l'utilisateur
  d'écouter avant de conclure) ;
- fins délavées (une « lueur » demandée dans le prompt blanchit l'objet à la fin), objets parasites qui apparaissent ;
- silences en début de clip (à couper au montage).

## Pièges Higgsfield déjà rencontrés

- Télécharger `result_url` du JSON du job : quand le job a des références, le JSON contient aussi leurs URL
  (`params.input_images`, `…_resize.jpg`) et un aperçu réduit (`min_result_url`, webp).
- Envoi direct d'une image parfois en erreur HTTP 520 : `higgsfield upload create` puis passer l'identifiant.
- `not_enough_boost_credits` alors que le solde est positif : la réserve « Concurrent Boost » est vide ; le dire à
  l'utilisateur (vérifier sur le site), ne pas réessayer en boucle.
- Depuis Python, appeler `node.exe …\@higgsfield\cli\bin\higgsfield.js` (le `.cmd` ne passe pas par subprocess).
- Ne jamais déplacer ni renommer un fichier d'entrée pendant qu'un lot tourne (un clip a échoué ainsi).
- Les voix ElevenLabs de l'utilisateur ne sont pas utilisables via Higgsfield (seulement ses voix maison).
