"""elevenlabs_voix.py — texte → voix off ElevenLabs en une seule prise.

Usage :
  python elevenlabs_voix.py voix-off.txt --voice <voice_id> --out voix/voix-off.mp3
         [--model eleven_v4] [--stability 0.5] [--similarity 0.75] [--style 0] [--speed 1.0]
         [--format mp3_44100_128]

Clé : ELEVENLABS_API_KEY (environnement, puis ~/.config/elevenlabs/.env). Elle n'est jamais affichée.
Le fichier est écrit à côté avec un suffixe de réglages (…_sp100_s50_sb75_eleven_v4.mp3) si --out n'est pas donné,
pour retrouver les réglages d'une prise plus tard (phrase de remplacement).

Une génération ElevenLabs consomme des caractères de l'abonnement de l'utilisateur : la lancer seulement après qu'il
a validé le texte et la voix.
"""
import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")


def find_key():
    if os.environ.get("ELEVENLABS_API_KEY"):
        return os.environ["ELEVENLABS_API_KEY"]
    f = Path.home() / ".config" / "elevenlabs" / ".env"
    if f.exists():
        for line in f.read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.strip().startswith("ELEVENLABS_API_KEY="):
                return line.split("=", 1)[1].strip().strip("'\"")
    sys.exit("Pas de clé ELEVENLABS_API_KEY (environnement ou ~/.config/elevenlabs/.env). "
             "Demander à l'utilisateur de l'ajouter lui-même dans ce fichier.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("text_file")
    ap.add_argument("--voice", required=True)
    ap.add_argument("--out")
    ap.add_argument("--model", default="eleven_v4")
    ap.add_argument("--stability", type=float, default=0.5)
    ap.add_argument("--similarity", type=float, default=0.75)
    ap.add_argument("--style", type=float, default=0.0)
    ap.add_argument("--speed", type=float, default=1.0)
    ap.add_argument("--format", default="mp3_44100_128",
                    help="les offres d'entrée de gamme refusent mp3_44100_192")
    a = ap.parse_args()

    text = Path(a.text_file).read_text(encoding="utf-8").strip()
    if not text:
        sys.exit("texte vide")
    tag = f"sp{round(a.speed * 100)}_s{round(a.stability * 100)}_sb{round(a.similarity * 100)}_{a.model}"
    out = Path(a.out) if a.out else Path(a.text_file).with_name(Path(a.text_file).stem + "_" + tag + ".mp3")
    out.parent.mkdir(parents=True, exist_ok=True)

    settings = {"stability": a.stability, "similarity_boost": a.similarity, "style": a.style,
                "use_speaker_boost": True}
    if a.speed != 1.0:
        settings["speed"] = a.speed
    body = json.dumps({"text": text, "model_id": a.model, "voice_settings": settings}).encode("utf-8")
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{a.voice}?output_format={a.format}"
    req = urllib.request.Request(url, data=body, headers={"xi-api-key": find_key(), "Content-Type": "application/json",
                                                          "Accept": "audio/mpeg"})
    print(f"{len(text)} caractères → voix {a.voice}, modèle {a.model}, {tag}")
    try:
        with urllib.request.urlopen(req, timeout=600) as r:
            out.write_bytes(r.read())
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:400]
        hint = ""
        if e.code == 401:
            hint = " (clé refusée ou sans le droit « Text to Speech »)"
        elif "output_format" in detail or "format" in detail:
            hint = " (format refusé par l'offre : essayer --format mp3_44100_128)"
        elif "model" in detail:
            hint = " (modèle indisponible : essayer --model eleven_multilingual_v2)"
        sys.exit(f"ElevenLabs HTTP {e.code}{hint} : {detail}")
    print("écrit :", out, f"({out.stat().st_size // 1024} Ko)")


if __name__ == "__main__":
    main()
