"""planche_contact.py — planches pour comparer et contrôler images et vidéos (à regarder avec Read).

Usage :
  python planche_contact.py variantes <dossier> --out <dossier_planches>
      Une planche par plan : les variantes « nom_1.png, nom_2.png, nom_3.png » côte à côte, numérotées.
  python planche_contact.py selection <dossier> --out selection.jpg [--cols 6]
      Toutes les images du dossier (ex. images/plans/clipNN.png) en grille, avec leur nom.
  python planche_contact.py videos <dossier ou clip.mp4 …> --out <dossier_planches> [--frames 4]
      Pour chaque clip : 4 images réparties sur sa durée + une planche d'ensemble (première image de chaque clip).
  python planche_contact.py visages <clip.mp4> --out bouches.jpg --crop 0.30,0.15,0.40,0.30 [--fps 4]
      Le même cadrage (x,y,largeur,hauteur en fraction de l'image) image par image : pour voir si des lèvres bougent
      alors que la voix est hors champ.

Les planches sont réduites (≈ 1600 px de large) pour être lisibles d'un coup ; zoomer sur l'original avant de
trancher un détail (doigts, nombre d'objets, texte de l'emballage).
"""
import argparse
import glob
import os
import re
import subprocess
import sys
import tempfile

from PIL import Image, ImageDraw, ImageFont

sys.stdout.reconfigure(encoding="utf-8")
IMG_EXT = (".png", ".jpg", ".jpeg", ".webp")


def font(size):
    for f in ("arialbd.ttf", "Arial Bold.ttf", "DejaVuSans-Bold.ttf", "arial.ttf"):
        try:
            return ImageFont.truetype(f, size)
        except OSError:
            continue
    return ImageFont.load_default()


def label(im, text, size=None):
    d = ImageDraw.Draw(im)
    size = size or max(18, im.width // 14)
    f = font(size)
    box = d.textbbox((0, 0), text, font=f)
    d.rectangle([0, 0, box[2] + 16, box[3] + 12], fill=(0, 0, 0))
    d.text((8, 4), text, fill=(255, 255, 0), font=f)
    return im


def grid(images, labels, cols, cell_w, out):
    if not images:
        sys.exit("aucune image")
    thumbs = []
    for im, lab in zip(images, labels):
        im = im.convert("RGB")
        h = round(im.height * cell_w / im.width)
        thumbs.append(label(im.resize((cell_w, h), Image.LANCZOS), lab))
    cell_h = max(t.height for t in thumbs)
    rows = (len(thumbs) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * cell_w + (cols - 1) * 8, rows * cell_h + (rows - 1) * 8), (40, 40, 40))
    for i, t in enumerate(thumbs):
        sheet.paste(t, ((i % cols) * (cell_w + 8), (i // cols) * (cell_h + 8)))
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    sheet.save(out, quality=88)
    print("écrit :", out)


def variantes(src, out_dir):
    groups = {}
    for f in sorted(os.listdir(src)):
        m = re.match(r"(.+)_(\d+)\.(png|jpe?g|webp)$", f, re.I)
        if m:
            groups.setdefault(m.group(1), []).append((int(m.group(2)), os.path.join(src, f)))
    if not groups:
        sys.exit("aucune image nommée nom_1.png, nom_2.png… dans " + src)
    for name, items in sorted(groups.items()):
        items.sort()
        grid([Image.open(p) for _, p in items], [f"{name} v{k}" for k, _ in items], len(items), 540,
             os.path.join(out_dir, f"{name}.jpg"))


def selection(src, out, cols):
    files = sorted(f for f in glob.glob(os.path.join(src, "*")) if f.lower().endswith(IMG_EXT))
    cell = max(160, min(400, 1600 // cols))
    grid([Image.open(f) for f in files], [os.path.splitext(os.path.basename(f))[0] for f in files], cols, cell, out)


def duration(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path],
                       capture_output=True, text=True)
    return float(r.stdout.strip())


def frame_at(path, t, tmp):
    dest = os.path.join(tmp, f"f_{abs(hash((path, t)))}.png")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{t:.3f}", "-i", path, "-frames:v", "1", dest],
                   check=True)
    return Image.open(dest)


def videos(sources, out_dir, n):
    files = []
    for s in sources:
        files += sorted(glob.glob(os.path.join(s, "*.mp4"))) if os.path.isdir(s) else [s]
    firsts, names = [], []
    with tempfile.TemporaryDirectory() as tmp:
        for f in files:
            d = duration(f)
            times = [d * (k + 0.5) / n for k in range(n)]
            ims = [frame_at(f, t, tmp) for t in times]
            name = os.path.splitext(os.path.basename(f))[0]
            grid(ims, [f"{name} {t:.1f}s" for t in times], n, 360, os.path.join(out_dir, f"{name}.jpg"))
            firsts.append(ims[0])
            names.append(name)
        grid(firsts, names, 6, 260, os.path.join(out_dir, "_ensemble.jpg"))


def visages(path, out, crop, fps):
    x, y, w, h = (float(v) for v in crop.split(","))
    with tempfile.TemporaryDirectory() as tmp:
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", path, "-vf",
                        f"fps={fps},crop=iw*{w}:ih*{h}:iw*{x}:ih*{y}", os.path.join(tmp, "c_%04d.png")], check=True)
        files = sorted(glob.glob(os.path.join(tmp, "c_*.png")))
        ims = [Image.open(f) for f in files]
        grid(ims, [f"{i / fps:.2f}s" for i in range(len(ims))], 8, 200, out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["variantes", "selection", "videos", "visages"])
    ap.add_argument("src", nargs="+")
    ap.add_argument("--out", required=True)
    ap.add_argument("--cols", type=int, default=6)
    ap.add_argument("--frames", type=int, default=4)
    ap.add_argument("--crop", default="0.25,0.10,0.50,0.35")
    ap.add_argument("--fps", type=float, default=4)
    a = ap.parse_args()
    if a.mode == "variantes":
        variantes(a.src[0], a.out)
    elif a.mode == "selection":
        selection(a.src[0], a.out, a.cols)
    elif a.mode == "videos":
        videos(a.src, a.out, a.frames)
    else:
        visages(a.src[0], a.out, a.crop, a.fps)


if __name__ == "__main__":
    main()
