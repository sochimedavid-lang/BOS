"""higgsfield_videos.py — génère les clips Kling image→vidéo, une seule fois chacun, par vagues.

Usage :
  python higgsfield_videos.py jobs.json --out <dossier>          # tableau des clips + coût total, n'envoie rien
  python higgsfield_videos.py jobs.json --out <dossier> --go     # envoie

jobs.json :
  [{"clip": "01", "image": "images/plans/clip01.png", "prompt": "…", "duration": 3, "sound": "off"}, …]
  - duration : secondes entières, minimum 3, SANS marge (voir durees_plans.py) ;
  - sound : "off" (voix off) ou "on" (dialogue joué par Kling, rire, bruit synchronisé).
Options : --model kling3_0 (défaut) --mode std (défaut ; « pro » refusé par l'utilisateur jusqu'ici)
          --aspect 9:16 --wave 4
Sortie : <dossier>/clipNN.mp4 et <dossier>/videos_state.json.

Règles : un clip déjà lancé ou en échec n'est jamais relancé (le retirer de l'état seulement avec l'accord de
l'utilisateur) ; ne pas déplacer ni renommer les images pendant que le lot tourne.
"""
import argparse
import json
import math
import os
import re
import sys
import time
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hf_common import State, hf, job_ids, log, result_url, upload, is_rate_limit, is_boost_error  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8")
# Kling v3.0 std constaté : 1,5 crédit/s sans son, 2 crédits/s avec. Vérifier avec `higgsfield generate cost`.
TARIF = {("std", "off"): 1.5, ("std", "on"): 2.0}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("jobs")
    ap.add_argument("--out", required=True)
    ap.add_argument("--go", action="store_true")
    ap.add_argument("--model", default="kling3_0")
    ap.add_argument("--mode", default="std")
    ap.add_argument("--aspect", default="9:16")
    ap.add_argument("--wave", type=int, default=4)
    a = ap.parse_args()

    base = os.path.dirname(os.path.abspath(a.jobs))
    jobs = json.load(open(a.jobs, encoding="utf-8"))
    for j in jobs:
        j["clip"] = str(j["clip"]).zfill(2)
        j["image"] = j["image"] if os.path.isabs(j["image"]) else os.path.join(base, j["image"])
        j["duration"] = max(3, math.ceil(float(j["duration"])))
        j["sound"] = j.get("sound", "off")
        if not os.path.exists(j["image"]):
            sys.exit(f"image introuvable pour le clip {j['clip']} : {j['image']}")

    os.makedirs(a.out, exist_ok=True)
    st = State(os.path.join(a.out, "videos_state.json"), {"uploads": {}, "clips": {}})
    clips = st.data["clips"]

    total, secs = 0.0, 0
    print(f"{'clip':>4} {'durée':>5} {'son':>4} {'crédits':>8}  état")
    for j in jobs:
        rate = TARIF.get((a.mode, j["sound"]))
        cost = j["duration"] * rate if rate else float("nan")
        done = clips.get(j["clip"], {})
        etat = "déjà téléchargé" if done.get("file") else ("ÉCHEC (non relancé)" if done.get("error") else
                                                            ("en cours" if done.get("job_id") else "nouveau"))
        if etat == "nouveau":
            total += cost
            secs += j["duration"]
        print(f"{j['clip']:>4} {j['duration']:>4}s {j['sound']:>4} {cost:>8.1f}  {etat}")
    print(f"À envoyer : {secs} s → ≈ {total:.1f} crédits ({a.model} {a.mode} {a.aspect})")
    if not a.go:
        print("Rien n'a été envoyé. Relancer avec --go après l'accord de l'utilisateur.")
        return

    for i in range(0, len(jobs), a.wave):
        wave = jobs[i:i + a.wave]
        for j in wave:
            submit(st, j, a)
        for j in wave:
            collect(st, j, a.out)
    ok = [c for c, s in sorted(clips.items()) if s.get("file")]
    log("FIN :", len(ok), "vidéos OK")
    bad = {c: s.get("error") for c, s in sorted(clips.items()) if s.get("error")}
    if bad:
        log("ÉCHECS (à signaler avec le coût d'une reprise, rien n'est relancé) :",
            json.dumps(bad, ensure_ascii=False)[:2000])


def submit(st, j, a):
    s = st.data["clips"].setdefault(j["clip"], {})
    if s.get("job_id") or s.get("error") or s.get("file"):
        return
    up = upload(j["image"], st.data["uploads"], st.save)
    args = ["generate", "create", a.model, "--prompt", j["prompt"], "--start-image", up, "--aspect_ratio", a.aspect,
            "--duration", str(j["duration"]), "--mode", a.mode, "--sound", j["sound"], "--json"]
    for _ in range(5):
        code, out, err = hf(args, 600)
        ids = job_ids(out, exclude=[up])
        if code == 0 and ids:
            s.update(job_id=ids[0], duration=j["duration"], sound=j["sound"])
            st.save()
            log("clip", j["clip"], "lancé", f"({j['duration']} s, son {j['sound']})")
            return
        msg = (err or out).strip()
        if is_rate_limit(msg):
            log("  limite de file, nouvelle tentative dans 60 s :", msg[:150])
            time.sleep(60)
            continue
        s["error"] = "création refusée : " + msg[:300]
        st.save()
        log("clip", j["clip"], "ERREUR", msg[:200])
        if is_boost_error(msg):
            log("  → réserve « Concurrent Boost » vide : prévenir l'utilisateur, ne pas réessayer en boucle.")
        return


def collect(st, j, out_dir):
    s = st.data["clips"].get(j["clip"], {})
    if not s.get("job_id") or s.get("file") or s.get("error"):
        return
    code, out, err = hf(["generate", "wait", s["job_id"], "--json", "--quiet", "--timeout", "25m"], 1700)
    url = result_url(out)
    if url:
        dest = os.path.join(out_dir, f"clip{j['clip']}.mp4")
        urllib.request.urlretrieve(url, dest)
        s["file"], s["url"] = os.path.abspath(dest), url
        log("clip", j["clip"], "terminé")
    else:
        status = re.findall(r'"status"\s*:\s*"([a-z_]+)"', out)
        s["error"] = f"pas de vidéo (statut {status[:1]}) : " + (err or out).strip()[:300]
        log("clip", j["clip"], "ÉCHEC", s["error"][:200])
    st.save()


if __name__ == "__main__":
    main()
