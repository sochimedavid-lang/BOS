"""durees_plans.py — voix off enregistrée → début, longueur et durée Kling de chaque plan, avec le coût.

Usage :
  python durees_plans.py whisper-words.json plans.json [--audio voix-off.mp3] [--lead 0.1]
                         [--jobs jobs.json] [--out durees.json]

- whisper-words.json : sortie de montage-pub-ia/scripts/transcribe-words.py ({"words": [{"word","start","end"}…]}).
- plans.json : [{"clip": "01", "vo": "texte exact dit pendant ce plan", "sound": "off"}, …] dans l'ordre.
  (« vo » vide pour un plan sans parole : il se partage le temps avec ses voisins ; vérifier sa durée à la main.)
- --audio : la vraie durée de la voix (sinon fin du dernier mot + 0,3 s).
- --jobs : écrit la durée Kling dans le jobs.json de higgsfield_videos.py (champ « duration », par clip).

Règles appliquées :
- chaque coupe tombe --lead s (0,1) avant le premier mot du plan ; le premier plan commence à 0 ;
- durée Kling = longueur du plan arrondie à la seconde supérieure, minimum 3 s, SANS marge : Kling étire le jeu sur
  toute la durée demandée, une marge ne fait que coûter. Ne rien ajouter sans l'accord de l'utilisateur.
- l'alignement texte ↔ transcription tolère les fautes de Whisper sur les noms ; les plans dont le premier mot n'a pas
  été retrouvé sont marqués « ~ » (vérifier à l'oreille).
"""
import argparse
import difflib
import json
import math
import os
import re
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
TARIF = {"off": 1.5, "on": 2.0}  # Kling v3.0 std, crédits par seconde (constaté)

UNITS = "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen " \
        "seventeen eighteen nineteen".split()
TENS = "_ _ twenty thirty forty fifty sixty seventy eighty ninety".split()


def num_words(n):
    if n < 20:
        return [UNITS[n]]
    if n < 100:
        return [TENS[n // 10]] + ([UNITS[n % 10]] if n % 10 else [])
    if n < 1000:
        return [UNITS[n // 100], "hundred"] + (num_words(n % 100) if n % 100 else [])
    return [str(n)]


def tokens(text):
    out = []
    for t in re.findall(r"[a-zà-ÿ0-9']+", text.lower().replace("’", "'").replace("-", " ")):
        t = t.strip("'")
        if t.isdigit():
            out += num_words(int(t))
        elif t:
            out.append(t)
    return out


def audio_duration(path):
    if not os.path.exists(path):
        sys.exit("audio introuvable : " + path)
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path],
                       capture_output=True, text=True)
    return float(r.stdout.strip())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("words")
    ap.add_argument("plans")
    ap.add_argument("--audio")
    ap.add_argument("--lead", type=float, default=0.1)
    ap.add_argument("--jobs")
    ap.add_argument("--out")
    a = ap.parse_args()

    W = json.load(open(a.words, encoding="utf-8"))
    W = W["words"] if isinstance(W, dict) else W
    plans = json.load(open(a.plans, encoding="utf-8"))

    # mots de la transcription (un mot Whisper peut donner plusieurs jetons : « 14 » → fourteen)
    wt, wtime = [], []
    for w in W:
        for t in tokens(w["word"]):
            wt.append(t)
            wtime.append((w["start"], w["end"]))
    # jetons du script, avec le plan auquel ils appartiennent
    st, owner = [], []
    for i, p in enumerate(plans):
        for t in tokens(p.get("vo", "")):
            st.append(t)
            owner.append(i)

    match = {}
    for b in difflib.SequenceMatcher(None, st, wt, autojunk=False).get_matching_blocks():
        for k in range(b.size):
            match[b.a + k] = b.b + k

    avg = (wtime[-1][1] - wtime[0][0]) / max(1, len(wt)) if wt else 0.35
    first_word = []
    for i, p in enumerate(plans):
        idx = [k for k, o in enumerate(owner) if o == i]
        if not idx:
            first_word.append(None)
            continue
        hit = next(((n, match[k]) for n, k in enumerate(idx) if k in match), None)
        if hit is None:
            first_word.append(None)
        else:
            n, wi = hit
            first_word.append((wtime[wi][0] - n * avg, n > 0))

    end_audio = audio_duration(a.audio) if a.audio else (W[-1]["end"] + 0.3 if W else 0)

    # début de chaque plan
    starts = []
    for i, p in enumerate(plans):
        if i == 0:
            starts.append(0.0)
        elif first_word[i] is not None:
            starts.append(max(starts[-1], first_word[i][0] - a.lead))
        else:
            starts.append(None)
    # plans sans mot retrouvé (ou muets) : répartis à parts égales entre les voisins connus
    i = 1
    while i < len(plans):
        if starts[i] is not None:
            i += 1
            continue
        j = i
        while j < len(plans) and starts[j] is None:
            j += 1
        prev, nxt = starts[i - 1], (starts[j] if j < len(plans) else end_audio)
        for k in range(i, j):
            starts[k] = prev + (nxt - prev) * (k - i + 1) / (j - i + 1)
        i = j

    rows, total, secs = [], 0.0, 0
    print(f"{'plan':>4} {'début':>7} {'longueur':>8} {'Kling':>5} {'son':>4} {'crédits':>7}")
    for i, p in enumerate(plans):
        end = starts[i + 1] if i + 1 < len(plans) else end_audio
        seg = end - starts[i]
        dur = max(3, math.ceil(round(seg, 2)))
        sound = p.get("sound", "off")
        cost = dur * TARIF.get(sound, float("nan"))
        total += cost
        secs += dur
        approx = "~" if (p.get("vo") and (first_word[i] is None or first_word[i][1])) else " "
        print(f"{str(p['clip']).zfill(2):>4} {starts[i]:6.2f}s{approx}{seg:7.2f}s {dur:4d}s {sound:>4} {cost:7.1f}")
        rows.append({"clip": str(p["clip"]).zfill(2), "start": round(starts[i], 2), "segment": round(seg, 2),
                     "duration": dur, "sound": sound, "credits": cost})
    print(f"Total : {len(plans)} plans, {secs} s de vidéo, ≈ {total:.1f} crédits ; voix {end_audio:.2f} s")
    print("« ~ » = début estimé (premier mot du plan non retrouvé dans la transcription) : vérifier.")

    if a.out:
        json.dump(rows, open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if a.jobs:
        jobs = json.load(open(a.jobs, encoding="utf-8"))
        by = {r["clip"]: r["duration"] for r in rows}
        for j in jobs:
            c = str(j["clip"]).zfill(2)
            if c in by:
                j["duration"] = by[c]
        json.dump(jobs, open(a.jobs, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print("durées écrites dans", a.jobs)


if __name__ == "__main__":
    main()
