"""recouvrement_scripts.py — mesure à quel point des scripts se ressemblent (suites de 4 mots communes).

Usage :
  python recouvrement_scripts.py crea-1/script.md crea-2/script.md [crea-3/script.md …] [--section "Script"] [--n 4]

- Pour un .md, --section garde seulement la partie sous le premier titre qui contient ce mot (jusqu'au titre suivant
  de même niveau) : en pratique la section voix off / dialogue, sans les notes ni les tableaux.
- Pour chaque paire : % des suites de n mots du plus court script qu'on retrouve dans l'autre, et les passages communs.

Repère : au-delà de ~25 %, la nouvelle créa répète l'ancienne (même accroche, mêmes phrases) ; réécrire l'angle,
pas seulement les mots. Les mentions obligatoires (livraison, garantie, « voyez un médecin ») comptent : les
formuler un peu différemment d'une créa à l'autre.
"""
import argparse
import itertools
import re
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")


def section(text, name):
    lines = text.splitlines()
    for i, line in enumerate(lines):
        m = re.match(r"^(#+)\s+(.*)", line)
        if m and name.lower() in m.group(2).lower():
            level = len(m.group(1))
            out = []
            for nxt in lines[i + 1:]:
                m2 = re.match(r"^(#+)\s", nxt)
                if m2 and len(m2.group(1)) <= level:
                    break
                out.append(nxt)
            return "\n".join(out)
    return text


def words(text):
    text = re.sub(r"\[[^\]]*\]|\([^)]*\)", " ", text)       # didascalies [rire] (pause)
    text = re.sub(r"^\s*\|.*$", " ", text, flags=re.M)        # tableaux
    text = re.sub(r"\*\*?[^*]{0,40}\*\*?\s*:", " ", text)     # noms de locuteurs en gras
    return re.findall(r"[a-zà-ÿ0-9']+", text.lower().replace("’", "'"))


def grams(w, n):
    return {tuple(w[i:i + n]) for i in range(len(w) - n + 1)}


def shared_passages(a, b, n):
    """Regroupe les n-grammes communs consécutifs de a en passages lisibles."""
    gb = grams(b, n)
    hits = [i for i in range(len(a) - n + 1) if tuple(a[i:i + n]) in gb]
    out, start, prev = [], None, None
    for i in hits + [None]:
        if start is None:
            start = prev = i
        elif i is not None and i == prev + 1:
            prev = i
        else:
            out.append(" ".join(a[start:prev + n]))
            start = prev = i
    return [p for p in out if p]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    ap.add_argument("--section")
    ap.add_argument("--n", type=int, default=4)
    a = ap.parse_args()
    if len(a.files) < 2:
        sys.exit("donner au moins deux scripts")

    texts = {}
    for f in a.files:
        t = Path(f).read_text(encoding="utf-8")
        if a.section and f.endswith(".md"):
            t = section(t, a.section)
        texts[f] = words(t)
        print(f"{Path(f).name}: {len(texts[f])} mots")

    for f1, f2 in itertools.combinations(a.files, 2):
        w1, w2 = texts[f1], texts[f2]
        short, long_ = (w1, w2) if len(w1) <= len(w2) else (w2, w1)
        g = grams(short, a.n)
        pct = 100 * len(g & grams(long_, a.n)) / max(1, len(g))
        flag = "  ← TROP PROCHE" if pct > 25 else ""
        print(f"\n{Path(f1).name} ↔ {Path(f2).name} : {pct:.0f} % de suites de {a.n} mots en commun{flag}")
        for p in shared_passages(short, long_, a.n)[:15]:
            print("   «", p, "»")


if __name__ == "__main__":
    main()
