"""higgsfield_images.py — génère des images Nano Banana Pro en variantes, références envoyées une seule fois.

Usage :
  python higgsfield_images.py jobs.json --out <dossier>          # affiche le nombre d'images et le coût, n'envoie rien
  python higgsfield_images.py jobs.json --out <dossier> --go     # envoie
  python higgsfield_images.py --refetch --out <dossier>          # retélécharge les images déjà générées (result_url)

jobs.json :
  [{"name": "clip01", "prompt": "…", "refs": ["images/references/ref_heros.png", …], "aspect": "9:16", "n": 3}]
  - aspect : "16:9" pour les références (fiches, décors, accessoires), "9:16" pour les plans.
  - n : nombre de variantes (3 par défaut).
Sortie : <dossier>/<name>_<k>.png et <dossier>/state.json (un job déjà créé n'est jamais renvoyé).

Ne lancer avec --go qu'après l'accord de l'utilisateur sur le nombre d'images et le coût.
"""
import argparse
import json
import os
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hf_common import State, hf, job_ids, log, result_url, upload, is_boost_error  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8")
CREDITS_PAR_IMAGE = 2  # Nano Banana Pro 2k, constaté ; vérifier avec `higgsfield generate cost` en cas de doute


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("jobs", nargs="?")
    ap.add_argument("--out", required=True)
    ap.add_argument("--go", action="store_true")
    ap.add_argument("--refetch", action="store_true")
    ap.add_argument("--resolution", default="2k")
    ap.add_argument("--workers", type=int, default=6)
    a = ap.parse_args()

    os.makedirs(a.out, exist_ok=True)
    st = State(os.path.join(a.out, "state.json"), {"uploads": {}, "jobs": {}})

    if a.refetch:
        return refetch(st, a.out)
    if not a.jobs:
        sys.exit(__doc__)

    jobs = json.load(open(a.jobs, encoding="utf-8"))
    keys = [f"{j['name']}_{k}" for j in jobs for k in range(1, j.get("n", 3) + 1)]
    new = [k for k in keys if k not in st.data["jobs"]]
    print(f"{len(jobs)} prompts, {len(keys)} images dont {len(new)} nouvelles "
          f"→ ≈ {len(new) * CREDITS_PAR_IMAGE} crédits")
    if not a.go:
        print("Rien n'a été envoyé. Relancer avec --go après l'accord de l'utilisateur.")
        return

    base = os.path.dirname(os.path.abspath(a.jobs))
    for j in jobs:
        ref_ids = [upload(p if os.path.isabs(p) else os.path.join(base, p), st.data["uploads"], st.save)
                   for p in j.get("refs", [])]
        for k in range(1, j.get("n", 3) + 1):
            submit(st, j, f"{j['name']}_{k}", ref_ids, a.resolution)
    with ThreadPoolExecutor(a.workers) as ex:
        list(ex.map(lambda k: collect(st, a.out, k), keys))
    ok = [k for k in keys if st.data["jobs"][k].get("file")]
    log("FIN", len(ok), "/", len(keys), "images")
    bad = {k: st.data["jobs"][k].get("error") for k in keys if not st.data["jobs"][k].get("file")}
    if bad:
        log("ÉCHECS (rien n'est relancé automatiquement) :", json.dumps(bad, ensure_ascii=False)[:1500])


def submit(st, j, key, ref_ids, resolution):
    if key in st.data["jobs"]:
        return
    args = ["generate", "create", "nano_banana_pro", "--prompt", j["prompt"], "--aspect_ratio", j.get("aspect", "9:16"),
            "--resolution", resolution, "--json"]
    for r in ref_ids:
        args += ["--image-references", r]
    code, out, err = hf(args, 600)
    ids = job_ids(out, exclude=ref_ids)
    if code == 0 and ids:
        st.data["jobs"][key] = {"id": ids[0]}
        log("lancé", key)
    else:
        msg = (err or out).strip()
        st.data["jobs"][key] = {"error": msg[:300]}
        log("ERREUR", key, msg[:200])
        if is_boost_error(msg):
            log("  → réserve « Concurrent Boost » vide : prévenir l'utilisateur, ne pas réessayer en boucle.")
    st.save()


def collect(st, out_dir, key):
    s = st.data["jobs"][key]
    if s.get("file") or s.get("error"):
        return
    code, out, err = hf(["generate", "wait", s["id"], "--json", "--quiet", "--timeout", "15m"], 1000)
    url = result_url(out)
    if url:
        ext = os.path.splitext(url.split("?")[0])[1] or ".png"
        dest = os.path.join(out_dir, key + ext)
        urllib.request.urlretrieve(url, dest)
        s["file"], s["url"] = os.path.abspath(dest), url
        log("ok", key)
    else:
        s["error"] = "pas d'image : " + (err or out).strip()[:300]
        log("ÉCHEC", key, s["error"][:150])
    st.save()


def refetch(st, out_dir):
    def one(key):
        s = st.data["jobs"][key]
        if not s.get("id"):
            return key, "pas de job"
        code, out, err = hf(["generate", "get", s["id"], "--json"], 300)
        url = result_url(out)
        if not url:
            return key, "pas de result_url"
        ext = os.path.splitext(url.split("?")[0])[1] or ".png"
        dest = os.path.join(out_dir, key + ext)
        urllib.request.urlretrieve(url, dest)
        s["file"], s["url"] = os.path.abspath(dest), url
        s.pop("error", None)
        return key, "ok"

    with ThreadPoolExecutor(3) as ex:
        res = list(ex.map(one, sorted(st.data["jobs"])))
    st.save()
    print("problèmes :", [r for r in res if r[1] != "ok"])


if __name__ == "__main__":
    main()
