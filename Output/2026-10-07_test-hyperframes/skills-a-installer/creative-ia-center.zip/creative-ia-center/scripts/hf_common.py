"""Outils communs aux scripts Higgsfield : appel de la CLI, upload, lecture des identifiants de job, état sur disque."""
import json
import os
import re
import shutil
import subprocess
import sys
import time

UUID = r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"


def hf_command():
    """Sous Windows, le `higgsfield.cmd` ne passe pas par subprocess : on appelle node + higgsfield.js directement."""
    if os.name == "nt":
        node = shutil.which("node") or r"C:\Program Files\nodejs\node.exe"
        js = os.path.join(os.environ.get("APPDATA", ""), "npm", "node_modules", "@higgsfield", "cli", "bin",
                          "higgsfield.js")
        if os.path.exists(js):
            return [node, js]
    exe = shutil.which("higgsfield") or shutil.which("hf")
    if not exe:
        sys.exit("CLI higgsfield introuvable (npm install -g @higgsfield/cli, puis higgsfield auth login).")
    return [exe]


HF = hf_command()


def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)


def hf(args, timeout=900):
    r = subprocess.run(HF + args, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout)
    return r.returncode, r.stdout or "", r.stderr or ""


class State:
    """Fichier d'état JSON : un job déjà créé n'est jamais renvoyé, même après un plantage."""

    def __init__(self, path, default):
        self.path = path
        self.data = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else default

    def save(self):
        tmp = self.path + ".tmp"
        json.dump(self.data, open(tmp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)


def upload(path, cache, save):
    """Envoie une image une seule fois (l'envoi direct échoue parfois en HTTP 520) ; renvoie son identifiant."""
    path = os.path.abspath(path)
    if path in cache:
        return cache[path]
    if not os.path.exists(path):
        raise SystemExit("fichier introuvable : " + path)
    for _ in range(3):
        code, out, err = hf(["upload", "create", path, "--json"], 600)
        m = re.search(r'"id"\s*:\s*"(' + UUID + ')"', out)
        if code == 0 and m:
            cache[path] = m.group(1)
            save()
            return m.group(1)
        log("  upload échoué", os.path.basename(path), (err or out).strip()[:150])
        time.sleep(15)
    raise SystemExit("upload impossible : " + path)


def job_ids(out, exclude=()):
    try:
        d = json.loads(out)
        d = d if isinstance(d, list) else (d.get("jobs") or d.get("job_ids") or [d])
        ids = [x if isinstance(x, str) else x.get("id") for x in d]
    except Exception:
        ids = re.findall(UUID, out)
    return [x for x in ids if x and x not in exclude]


def result_url(out):
    """Toujours `result_url` : le JSON contient aussi les URL des références (…_resize.jpg) et un aperçu webp."""
    try:
        d = json.loads(out)
        d = d[0] if isinstance(d, list) and d else d
        if isinstance(d, dict) and d.get("result_url"):
            return d["result_url"]
    except Exception:
        pass
    m = re.search(r'"result_url"\s*:\s*"([^"]+)"', out)
    return m.group(1) if m else None


def is_rate_limit(msg):
    return bool(re.search(r"limit|concurren|too many|429|queue is full", msg, re.I)) and "boost" not in msg.lower()


def is_boost_error(msg):
    return "boost" in msg.lower()
