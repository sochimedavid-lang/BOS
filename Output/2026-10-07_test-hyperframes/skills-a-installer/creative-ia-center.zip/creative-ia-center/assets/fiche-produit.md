# Fiche produit — <Produit>

_À remplir en phase 0, puis à tenir à jour. Une ligne « inconnu » vaut mieux qu'une supposition._

## Le produit
- Nom commercial affiché dans la pub :
- Ce que c'est (forme, contenu, nombre d'unités par boîte/sachet) :
- Mode d'emploi / posologie **réelle** (et ce que dit la page, si différent) :
- Durée couverte par une unité de vente (ex. 7 capsules, 1 tous les 2 jours = 14 jours) :
- Composition connue / inconnue (ne jamais inventer d'ingrédient) :
- Mentions à NE PAS montrer à l'écran (ex. noms de maladies sur l'emballage) :
- Photos de l'emballage réel (chemins) :

## Le marché
- Pays / villes de la cible :
- Langue de la pub (et accent de la voix) :
- Registre : tutoiement ou vouvoiement pour parler au spectateur ; expressions locales bienvenues / à éviter :
- Cible : âge, genre, situation ; acheteur = utilisateur ? (ou un proche qui achète pour lui)
- Plateforme : Meta (Facebook / Instagram) par défaut

## L'offre (ce qui est vrai aujourd'hui)
- Prix : … — affiché dans la vidéo ? non (par défaut)
- Offre groupée (ex. 2+1) : … — citée dans la vidéo ? à décider
- Livraison : gratuite ? délai ?
- Paiement : à la livraison ?
- Garantie (durée, conditions) — la même sur la page, dans les conditions et dans la pub :
- Contact / service client nommé ? (ne le citer que s'il existe vraiment)
- Durée du plan conseillé (ex. 4 semaines) — la même sur la page et dans la pub :

## La page produit
- Lien :
- Écarts constatés avec la réalité (posologie, promesses, images trompeuses) :

## Preuves disponibles
- Avis / verbatims de vrais clients (avec accord) :
- Études ou références vérifiables :
- Ce qui n'existe pas encore (à ne pas citer) :

## Choix créatifs
- Style de la créa 1 : (3D façon Pixar / humain IA réaliste / 2D / mascotte / autre)
- Qui génère les images : utilisateur sur le site (Unlimited) / moi en CLI
- Budget crédits indicatif :
