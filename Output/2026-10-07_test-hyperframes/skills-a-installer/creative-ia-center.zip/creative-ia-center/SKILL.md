---
name: creative-ia-center
description: 'Crée de A à Z des pubs vidéo IA (« créas ») pour un produit e-commerce, selon la méthode Mark Builds Brands : recherche et 4 documents fondateurs, choix du style de créa (3D façon Pixar, humain IA réaliste, 2D, mascotte…), swipe, script, storyboard, génération Higgsfield (images Nano Banana Pro, vidéos Kling), voix off ElevenLabs, montage, corrections et préparation du lancement Meta. Contexte par défaut : vente en Afrique avec paiement à la livraison. Utilise ce skill dès que l''utilisateur veut faire une pub, une créa ou une série de créas pour un produit, lancer un nouveau produit en pub vidéo, « refaire comme pour North Moon », reprendre une créa en cours, ou passer à l''étape suivante d''une créa (recherche, swipe, script, storyboard, images, vidéos, voix, montage) — même s''il ne nomme pas la méthode. Il coordonne watch, storyboard-ai-ad, montage-pub-ia et la CLI Higgsfield ; pour un simple montage de clips déjà prêts, montage-pub-ia suffit.'
---

# Creative IA Center

Chaîne complète pour transformer un produit en pubs vidéo IA qui vendent, tirée d'une première série réelle
(3 créas montées et validées). Le skill garde la méthode, les règles et les pièges ; tout le contenu propre à un
produit se trouve dans le dossier de ce produit, jamais ici.

## Les principes qui guident tout le reste

- **Un argument, pas des mots.** Une pub mène le spectateur vers une croyance précise avant de présenter le produit
  (mécanisme unique du problème, mécanisme unique de la solution, grande idée). On construit l'argument d'abord, on
  polit les mots ensuite.
- **Une créa = une question et une croyance.** Plusieurs créas pour un même produit doivent changer d'argument, de
  croyance visée, de héros, de décor et de forme. Une créa qui reprend plus de ~25 % des mots d'une autre (hors faits
  fixes et appel à l'action) est une redite : l'utilisateur l'a rejetée la première fois.
- **Tout ce qui est dit est vrai aujourd'hui.** Chaque script liste « ce qui est cité parce que vrai » et « ce qui
  n'est pas cité ». Si la page produit dit autre chose que la pub, on le signale avant le lancement.
- **L'utilisateur valide à chaque porte, et aucune dépense sans accord.** On lui montre les choix (avec 3 variantes
  pour les images) et le coût exact avant tout ce qui coûte des crédits : génération, régénération, durée, qualité,
  marge. On ne relance jamais une génération ratée sans lui demander.
- **Il ne peut pas voir ce que je vois, et je ne peux pas entendre.** Je décris les images avec précision (j'en zoome
  les détails) ; pour le son, je mesure (transcription, silences, volumes) et je lui donne les moments à écouter.

## Vue d'ensemble

| Phase | Ce qu'on produit | Porte de validation | Coût |
|---|---|---|---|
| 0. Lancement | Dossier produit + fiche produit + choix du style | Fiche produit et style confirmés | 0 |
| 1. Recherche | 4 documents fondateurs (recherche, avatar, offer brief, croyances) | L'utilisateur fournit ou valide les 4 docs | 0 (fait dans son outil de recherche) |
| 2. Swipe | Analyse de 2 à 4 pubs de référence → formats de créas | Choix des formats / créas à faire | 0 |
| 3. Script | Script de la créa (versions, relecture) | Script validé | 0 |
| 4. Storyboard | Fiche de cohérence + plans (prompts image, vidéo, son, durée) | Storyboard validé | 0 |
| 5a. Références | Fiches personnages, décors, accessoires (16:9) | Références validées | ~2 cr/image si je génère |
| 5b. Images de plans | 3 variantes par plan (9:16) → ma sélection | Sélection validée | ~2 cr/image si je génère |
| 5c. Voix | Voix off en une prise (ou dialogues) | Voix validée à l'oreille | Caractères ElevenLabs |
| 5d. Vidéos | Un clip par plan, généré une fois | Contrôle + accord pour toute reprise | Kling : 1,5 cr/s sans son, 2 cr/s avec |
| 6. Montage | Vidéo finale 9:16 avec sous-titres | L'utilisateur regarde et écoute | 0 |
| 6b. Habillage | Accroche animée en haut + carte de fin CTA (`habillage-pub`) | Aperçus validés, puis vidéo | 0 |
| 7. Corrections | Versions v2, v3… | À chaque version | Selon le cas |
| 8. Lancement | Page alignée, textes de pub, suivi | — | — |

Chaque phase a sa fiche détaillée dans `references/` : lis-la au moment d'entrer dans la phase, pas avant.

## Phase 0 — Lancer un produit

1. **Ouvre le dossier produit** : `Desktop\Claude\Pubs IA\<Produit>\` (crée-le s'il n'existe pas), avec la structure
   décrite dans `references/organisation-dossiers.md`. Si le produit existe déjà, lis d'abord son `SUIVI.md` pour
   reprendre où on en était.
2. **Remplis la fiche produit** à partir de `assets/fiche-produit.md` : produit, pays et langue de la pub, offre,
   prix (jamais affiché dans la vidéo, sauf demande explicite), posologie ou mode d'emploi réel, garantie réelle,
   lien de la page produit, preuves disponibles, ce qui n'existe pas encore. Pose les questions manquantes, en une
   fois, et vérifie la page produit toi-même (elle contient souvent des erreurs : posologie fausse, promesses
   intenables) — l'écart entre la page et la réalité est souvent la source des plaintes clients.
3. **Demande le style de créa** — c'est l'utilisateur qui choisit, ne suppose jamais la 3D :
   3D façon Pixar · humain IA réaliste (façon UGC) · 2D cartoon / motion design · mascotte produit · pâte à modeler ·
   anime · autre. Le style change les pubs de référence à chercher, la manière de garder les personnages cohérents,
   la façon de faire parler (voix off ou synchronisation des lèvres) et les risques de conformité :
   `references/styles.md`. Le style peut changer d'une créa à l'autre ; redemande-le à chaque nouvelle créa.
4. **Demande qui génère les images** pour cette créa : l'utilisateur sur le site Higgsfield (mode Unlimited,
   gratuit ; je fournis les prompts et je choisis parmi ses images) ou moi en ligne de commande (plus rapide,
   ~2 crédits par image). Donne le coût estimé des deux options.
5. Contexte par défaut : vente en Afrique avec paiement à la livraison et pub Meta. Les règles de conformité
   (`references/conformite.md`) s'appliquent dès l'écriture du premier mot.

## Phase 1 — Recherche : les 4 documents fondateurs

Lis `references/01-recherche.md`. En bref : on fait produire par un outil de recherche approfondie (Claude Research a
été le plus fiable ; Gemini a inventé des faits ; GPT restait générique) les 4 documents de Mark — document de
recherche, fiche avatar, offer brief, croyances nécessaires — avec ses prompts (`assets/mark-builds-brands/`). Je
prépare les prompts remplis pour le produit ; l'utilisateur lance la recherche ; je lis ensuite les 4 documents en
entier et je lui restitue ce que j'en retiens (marché, offre, limites pour le script, ce qui manque). Ses documents
priment sur tout brouillon que j'aurais fait.

## Phase 2 — Swipe

Lis `references/02-swipe.md`. L'utilisateur fournit 2 à 4 pubs de référence **dans le style choisi** (ou on les
cherche ensemble). Analyse chacune avec le skill `watch` (accroche, rythme, structure, ce qui la fait marcher, ce
qu'il ne faut pas reprendre), puis propose un format de créa par pub, en une ligne chacun. L'utilisateur choisit.

## Phase 3 — Script

Lis `references/03-script.md`. Méthode de Mark en 4 temps : analyser la recherche, analyser la structure du swipe,
réécrire pour le produit, relire (clarté, mots du client, ton humain, conformité). Livrable : un fichier
`crea-N-<nom>/script.md` avec le script, ce qui est cité parce que vrai, les croyances couvertes, 2-3 accroches
alternatives, les points à valider et la durée estimée (150 mots ≈ 60 s). Pour une 2e créa et suivantes, mesure le
recouvrement avec les précédentes (`scripts/recouvrement_scripts.py`).

## Phase 4 — Storyboard

Lis `references/04-storyboard.md`, puis applique le skill `storyboard-ai-ad` (il analyse les pubs de référence avec
`watch` avant d'écrire les plans). Ajoute-lui ce que l'expérience a appris : descripteurs identiques mot pour mot
d'un prompt à l'autre, décors locaux urbains par défaut, sachet ou emballage sans mention de maladie, mode de parole
choisi en fonction du style et de la voix (voir la fiche). Livrable : `crea-N-<nom>/storyboard.md`.

## Phase 5 — Génération

Lis `references/05-generation.md` (déroulé, critères de choix, pièges Higgsfield et Kling, coûts) et, pour la voix,
`references/voix.md`. L'ordre ne change pas :

1. **Références en 16:9** (fiche de chaque personnage, décors vides, planche d'accessoires et de l'emballage),
   3 variantes chacune → je choisis → l'utilisateur valide.
2. **Images de plans en 9:16**, 3 variantes par plan, générées avec les références → planches de comparaison
   (`scripts/planche_contact.py`) → je choisis en zoomant les détails → l'utilisateur valide.
3. **Voix** quand le script est en voix off : une seule prise pour toute la pub (`scripts/elevenlabs_voix.py`),
   transcrite pour caler la durée de chaque plan sur la vraie voix (`scripts/durees_plans.py`).
4. **Vidéos Kling**, une seule génération par plan, après accord sur les durées et le coût total
   (`scripts/higgsfield_videos.py`, qui n'envoie rien sans `--go`). Contrôle de chaque clip (images clés,
   transcription, lèvres) et signalement des défauts ; aucune reprise sans accord.

## Phase 6 — Montage

Lis `references/06-montage.md`, puis applique le skill `montage-pub-ia`. Prépare les sous-titres **avant** le rendu
pour n'encoder qu'une fois (`stage-ad.py --render`). Musique et bruitages : Pixabay (pas la bibliothèque CapCut, non
autorisée pour les pubs Meta), téléchargés par l'utilisateur (l'API Pixabay ne donne pas accès à l'audio).
Livre la vidéo avec la liste des bruitages et les moments précis à écouter.

## Phase 6b — Habillage

Une fois le montage validé, applique le skill `habillage-pub` : phrase d'accroche animée en haut de l'écran pendant
la première phrase (une des accroches alternatives du script) et carte de fin animée (produit détouré, bénéfice,
livraison gratuite, paiement à la livraison, bouton qui pointe vers le bouton de la pub). Validé par l'utilisateur :
à proposer pour chaque créa. Aperçus d'abord, puis rendu. Pas de prix sur la carte sauf décision explicite.

## Phase 7 — Corrections

Cible la plus petite intervention : son seul → `--swap-audio` (≈ 1 min, image intacte) ; un mot de voix off →
le reprendre ailleurs dans la même voix ou régénérer la phrase ; un plan → régénérer ce plan seul (avec accord).
Garde les versions précédentes (`_v1`, `_8weeks`…). Détails et cas déjà rencontrés : `references/06-montage.md`.

## Phase 8 — Avant et après le lancement

Lis `references/07-lancement.md` : aligner la page produit sur ce que disent les pubs (posologie, garantie,
durée du plan), écrire les textes de la pub, puis lire les chiffres (Mark : « on n'achète pas des pertes, on
achète des données »). Le connecteur Meta Ads doit être autorisé par l'utilisateur avant que je puisse l'utiliser.

## Règles permanentes

- **Coûts** : chaque génération, régénération, choix de durée, de qualité ou de marge est proposé avec son coût,
  puis attend un « oui ». Qualité Kling par défaut : `std`. Pas de marge de durée (Kling étire la réplique sur toute
  la durée donnée).
- **Validation** : après chaque lot (références, images, vidéos), planche de comparaison + choix motivés, puis
  attente du feu vert.
- **Formats** : références en 16:9 ; images de plans et vidéos en vertical 9:16 ; jamais de vue large de décor en 9:16.
- **Décors** : réalistes pour le pays de la cible, urbains et classe moyenne par défaut (voir
  `references/04-storyboard.md`) ; rural seulement si l'utilisateur le demande.
- **Conformité** : `references/conformite.md`, à relire à chaque script.
- **Suivi** : mets à jour `<Produit>/SUIVI.md` à chaque étape franchie (décisions, fichiers, coûts dépensés,
  prochaine étape), pour qu'une autre session reprenne sans rien redemander.

## Fichiers du skill

| Fichier | Quand le lire |
|---|---|
| `references/organisation-dossiers.md` | Phase 0 |
| `references/styles.md` | Phase 0, puis à chaque nouvelle créa |
| `references/01-recherche.md` | Phase 1 |
| `references/02-swipe.md` | Phase 2 |
| `references/03-script.md` | Phase 3 |
| `references/04-storyboard.md` | Phase 4 |
| `references/05-generation.md` | Phase 5 |
| `references/voix.md` | Phase 5 (voix) |
| `references/06-montage.md` | Phases 6 et 7 |
| `references/07-lancement.md` | Phase 8 |
| `references/conformite.md` | À chaque script et avant chaque génération |
| `assets/fiche-produit.md` | Phase 0 (à copier dans le dossier produit) |
| `assets/mark-builds-brands/` | Prompts et modèles de Mark (phase 1) |

Scripts (usage complet en tête de chaque fichier) — ceux qui coûtent n'envoient rien sans `--go` :

| Script | Rôle |
|---|---|
| `scripts/recouvrement_scripts.py` | % de passages communs entre scripts (redite au-delà de ~25 %) |
| `scripts/higgsfield_images.py` | Nano Banana Pro en variantes, références envoyées une fois ; `--refetch` |
| `scripts/planche_contact.py` | Planches : variantes côte à côte, sélection, images clés des vidéos, bouches image par image |
| `scripts/elevenlabs_voix.py` | Voix off en une prise (clé dans `~/.config/elevenlabs/.env`) |
| `scripts/durees_plans.py` | Voix transcrite → début, longueur, durée Kling et coût de chaque plan ; remplit `jobs.json` |
| `scripts/higgsfield_videos.py` | Kling image→vidéo par vagues, une fois par plan, état sur disque |
| `scripts/hf_common.py` | Fonctions partagées par les deux scripts Higgsfield |
